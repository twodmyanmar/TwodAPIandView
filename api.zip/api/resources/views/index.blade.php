<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>2D Thailand Myanmar</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div id="exampleWrapper" class="flex justify-center" >

        <div class="w-full max-w-2xl p-4 bg-blue-500 border border-gray-200 rounded-lg shadow sm:p-6 dark:bg-gray-800 dark:border-gray-700 mt-60" style="background-color: #01b0f1;">

            <ul class="my-4 space-y-3">
                <li class="p-2 mb-4 text-center">
                    <a href="/live1" class="nav-link items-center p-3 font-bold text-center text-white bg-red-600 rounded-lg hover:bg-red-500 group hover:shadow dark:bg-red-600 dark:hover:bg-red-500 dark:text-white" style="background-color:#fe0000;">

                        <span class="flex-1 text-center">2D => 12:00PM</span>
                        <span class="flex-1 font-bold text-center font-weight-bold">•</span>
                        <span class="flex-1 text-center">2D => 04:00PM</span>

                    </a>
                </li>


                <li class="p-2  text-center" >
                    <a href="#"
                        class="nav-link items-center p-3 font-bold text-center text-white bg-red-600 rounded-lg hover:bg-red-600 group hover:shadow dark:bg-red-600 dark:hover:bg-red-500 dark:text-white" style="background-color:#fe0000;">

                        <span class="flex-1 text-center">3D => 03:00PM</span>
                        <span class="flex-1 text-center">•</span>
                        <span class="flex-1 text-center">4D => 04:00PM</span>

                    </a>
                </li>

            </ul>

        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
</body>
</html>
